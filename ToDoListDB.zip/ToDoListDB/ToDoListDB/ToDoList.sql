﻿CREATE TABLE [dbo].[ToDoList]
(
	[ListId] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Date] NVARCHAR(50) NOT NULL, 
    [UserId] INT NOT NULL, 
    CONSTRAINT [FK_ToDoList_ToUser] FOREIGN KEY ([UserId]) REFERENCES [User]([UserId])
)
