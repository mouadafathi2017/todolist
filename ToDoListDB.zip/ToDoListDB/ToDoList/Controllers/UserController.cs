﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ToDoList.Models;

namespace ToDoList.Controllers
{
    public class UserController : Controller
    {
        private ToDoListDBEntities db = new ToDoListDBEntities();

        // GET: /User/
        public ActionResult Index()
        {
            return View(db.Users.ToList());
        }

        // GET: /User/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            User user = db.Users.Find(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            return View(user);
        }

        // GET: /User/Create
        public ActionResult Create()
        {
            return View();
        }

        public ActionResult Login()
        {
            return View();
        }

        // POST: /User/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include="UserId,fName,lName,Email,Password")] User user)
        {
            if (ModelState.IsValid)
            {
                    user.Code = user.fName + user.UserId + user.lName;
                    db.Users.Add(user);
                    db.SaveChanges();
                    return RedirectToAction("Index");
            }

            return View(user);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(String Email, String Password)
        {
            User user = db.Users.FirstOrDefault(u => u.Email == Email && u.Password == Password);
            if (user != null)
            {
                Session["user"] = user;
                return RedirectToAction("../ToDoList/");
            }
            else
                return HttpNotFound();
        }

        public ActionResult HomeUser()
        {
            if (Session["user"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Login");
            }
        }
        [HttpPost]
        public ActionResult Items(String Date)
        {
            if (Session["user"] != null)
            {
                Models.ToDoList toDoList = new Models.ToDoList { Date = Date };
                User user = db.Users.Find(((User)Session["user"]).UserId);
                user.ToDoLists.Add(toDoList);
                db.Entry(user).State = EntityState.Modified;
                //db.ToDoLists.Add(toDoList);
                db.SaveChanges();
                return RedirectToAction("../ToDoList");
            }
            else
            {
                return RedirectToAction("Login");
            }
        }

        // GET: /User/Edit/5
        public ActionResult Edit()
        {
            if (Session["user"] != null)
            {
                User user = db.Users.Find(((User)Session["user"]).UserId);
                return View(user);
            }
            else
            {
                return RedirectToAction("Login");
            }
        }

        // POST: /User/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(String UserId, String fName, String lName, String Email, String OldPassword, String NewPassword, String PassR)
        {
            if (Session["user"] != null)
            {
                if (NewPassword.Equals(PassR))
                {
                    User user = db.Users.Find(Convert.ToInt32(UserId));
                    if (OldPassword.Equals(user.Password))
                    {
                        user.fName = fName;
                        user.lName = lName;
                        user.Email = Email;
                        user.Password = NewPassword;
                        Session["user"] = user;
                        db.Entry(user).State = EntityState.Modified;
                        db.SaveChanges();
                        return RedirectToAction("../ToDoList");
                    }
                    else
                    
                        ViewBag.Error = "Old password is incorrect.";
                        return View(user);
                    }
                else
                {
                    User user_ = new User { UserId = Convert.ToInt32(UserId), fName = fName, lName = lName, Email = Email };
                    user_.fName = fName;
                    user_.lName = lName;
                    user_.Email = Email;
                    ViewBag.Error = "The two passwords don't match.";
                    return View(user_);
                }
            }
            else
            {
                return RedirectToAction("Login");
            }
        }

        // GET: /User/Delete/5
        public ActionResult Delete(int? id)
        {
            if (Session["user"] != null)
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                User user = db.Users.Find(id);
                if (user == null)
                {
                    return HttpNotFound();
                }
                return View(user);
            }
            else
            {
                return RedirectToAction("Login");
            }
        }

        // POST: /User/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            if (Session["user"] != null)
            {
                User user = db.Users.Find(id);
                db.Users.Remove(user);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return RedirectToAction("Login");
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
