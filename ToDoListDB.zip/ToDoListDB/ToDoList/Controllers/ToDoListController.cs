﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ToDoList.Models;

namespace ToDoList.Controllers
{
    public class ToDoListController : Controller
    {
        private ToDoListDBEntities db = new ToDoListDBEntities();

        // GET: /ToDoList/
        public ActionResult Index()
        {
            if (Session["user"] != null)
            {
                User usr = db.Users.Find(((User)Session["user"]).UserId);
                return View(usr.ToDoLists);
            }
            else
            {
                return RedirectToAction("../User/Login");
            }
        }

        // GET: /ToDoList/Details/5
        public ActionResult Details(int? id)
        {
            if (Session["user"] != null)
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Models.ToDoList todolist = db.ToDoLists.Find(id);
                if (todolist == null)
                {
                    return HttpNotFound();
                }
                return View(todolist);
            }
            else
            {
                return RedirectToAction("../User/Login");
            }
        }

        // GET: /ToDoList/Create
        public ActionResult Create()
        {
            if (Session["user"] != null)
            {
                ViewBag.UserId = new SelectList(db.Users, "UserId", "fName");
                return View();
            }
            else
            {
                return RedirectToAction("../User/Login");
            }
        }

        // POST: /ToDoList/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include="ListId,Date,UserId")] Models.ToDoList todolist)
        {
            if (Session["user"] != null)
            {
                if (ModelState.IsValid)
                {
                    db.ToDoLists.Add(todolist);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }

                ViewBag.UserId = new SelectList(db.Users, "UserId", "fName", todolist.UserId);
                return View(todolist);
            }
            else
            {
                return RedirectToAction("../User/Login");
            }
        }

        // GET: /ToDoList/Edit/5
        public ActionResult Edit(int? id)
        {
            if (Session["user"] != null)
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Models.ToDoList todolist = db.ToDoLists.Find(id);
                if (todolist == null)
                {
                    return HttpNotFound();
                }
                ViewBag.UserId = new SelectList(db.Users, "UserId", "fName", todolist.UserId);
                return View(todolist);
            }
            else
            {
                return RedirectToAction("../User/Login");
            }
        }

        // POST: /ToDoList/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="ListId,Date,UserId")] Models.ToDoList todolist)
        {
            if (Session["user"] != null)
            {
                if (ModelState.IsValid)
                {
                    db.Entry(todolist).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                ViewBag.UserId = new SelectList(db.Users, "UserId", "fName", todolist.UserId);
                return View(todolist);
            }
            else
            {
                return RedirectToAction("../User/Login");
            }
        }

        // GET: /ToDoList/Delete/5
        public ActionResult Delete(int? id)
        {
            if (Session["user"] != null)
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Models.ToDoList todolist = db.ToDoLists.Find(id);
                if (todolist == null)
                {
                    return HttpNotFound();
                }
                return View(todolist);
            }
            else
            {
                return RedirectToAction("../User/Login");
            }
        }

        // POST: /ToDoList/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            if (Session["user"] != null)
            {
                Models.ToDoList todolist = db.ToDoLists.Find(id);
                db.ToDoLists.Remove(todolist);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            else
            {
                return RedirectToAction("../User/Login");
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
