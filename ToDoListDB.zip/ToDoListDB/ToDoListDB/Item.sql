﻿CREATE TABLE [dbo].[Item]
(
	[ItemId] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Title] NVARCHAR(MAX) NOT NULL, 
    [State] INT NOT NULL, 
    [Time] NVARCHAR(50) NOT NULL, 
    [ListId] INT NOT NULL, 
    [Description] NVARCHAR(MAX) NULL, 
    CONSTRAINT [FK_Item_ToList] FOREIGN KEY (ListId) REFERENCES [ToDoList]([ListId])
)
