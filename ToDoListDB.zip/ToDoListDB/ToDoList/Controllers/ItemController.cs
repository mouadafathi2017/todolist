﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ToDoList.Models;

namespace ToDoList.Controllers
{
    public class ItemController : Controller
    {
        private ToDoListDBEntities db = new ToDoListDBEntities();

        // GET: /Item/
        public ActionResult Index()
        {
            var items = db.Items.Include(i => i.ToDoList);
            return View(items.ToList());
        }

        // GET: /Item/Details/5
        public ActionResult Details(int? id)
        {
            if (Session["user"] != null)
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Item item = db.Items.Find(id);
                if (item == null)
                {
                    return HttpNotFound();
                }
                return View(item);
            }
            else
            {
                return RedirectToAction("../User/Login");
            }
        }

        public ActionResult Done(int? id)
        {
            if (Session["user"] != null)
            {
                Item item = db.Items.Find(id);
                item.State = 1;
                db.Entry(item).State = EntityState.Modified;
                db.SaveChanges();
                ToDoListController tc = new ToDoListController();
                return RedirectToAction("../ToDoList/Details/" + item.ListId);
            }
            else
            {
                return RedirectToAction("../User/Login");
            }
        }

        // GET: /Item/Create
        public ActionResult Create(int? id)
        {
            if (Session["user"] != null)
            {
                @ViewBag.ListId = id;
                return View();
            }
            else
            {
                return RedirectToAction("../User/Login");
            }
        }

        // POST: /Item/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include="ItemId,Title,Description,Time")] Item item)
        {
            if (Session["user"] != null)
            {
                if (ModelState.IsValid)
                {
                    item.ListId = Convert.ToInt32(Request.Form["ListID"]);
                    item.State = 0;
                    db.Items.Add(item);
                    db.SaveChanges();
                    return RedirectToAction("../ToDoList/Details/" + item.ListId);
                }
                return View(item);
            }
            else
            {
                return RedirectToAction("../User/Login");
            }
        }

        // GET: /Item/Edit/5
        public ActionResult Edit(int? id)
        {
            if (Session["user"] != null)
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Item item = db.Items.Find(id);
                if (item == null)
                {
                    return HttpNotFound();
                }
                return View(item);
            }
            else
            {
                return RedirectToAction("../User/Login");
            }
        }

        // POST: /Item/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(String ItemId, String Title, String Description, String Time)
        {
            if (Session["user"] != null)
            {
                Item item_ = db.Items.Find(Convert.ToInt32(ItemId));
                item_.Title = Title;
                item_.Description = Description;
                item_.Time = Time;
                db.Entry(item_).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("/../ToDoList/Details/" + item_.ListId);
            }
            else
            {
                return RedirectToAction("../User/Login");
            }
        }

        // GET: /Item/Delete/5
        public ActionResult Delete(int? id)
        {
            if (Session["user"] != null)
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }
                Item item = db.Items.Find(id);
                if (item == null)
                {
                    return HttpNotFound();
                }
                return View(item);
            }
            else
            {
                return RedirectToAction("../User/Login");
            }
        }

        // POST: /Item/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            if (Session["user"] != null)
            {
                Item item = db.Items.Find(id);
                db.Items.Remove(item);
                db.SaveChanges();
                return RedirectToAction("../ToDoList/Details/" + item.ListId);
            }
            else
            {
                return RedirectToAction("../User/Login");
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
